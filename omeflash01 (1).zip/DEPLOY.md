# Guia Completo de Publicação e Autenticação do Vortex Stream

## Diagnóstico da Arquitetura

O projeto **Vortex Stream** é uma aplicação **Full-Stack**:
1. **Frontend**: Desenvolvido em React + Vite + Tailwind CSS.
2. **Backend**: Desenvolvido em Node.js (v22+) + Express + banco de dados SQLite (`server.ts` e diretório `server/`).
3. **Autenticação Real**: Implementada no backend via hash criptográfico `scrypt` com salt aleatório exclusivo por usuário (`server/auth.ts`), tabela `users` e sessões persistentes no banco `platform.db` (`server/routes/auth.ts`).

### Por que o login falha no Netlify com status 404 / não-JSON?
O **Netlify é um serviço de hospedagem exclusivo para arquivos estáticos** (`dist/index.html`, scripts JS e CSS). Ele compila o frontend com `npm run build`, mas **não executa servidores Node.js (`server.ts`)**.

Quando o frontend no Netlify tenta autenticar em `/api/auth/login`:
- Se a variável `VITE_API_URL` não estiver configurada no Netlify, o navegador busca `/api/auth/login` no próprio domínio do Netlify.
- O Netlify não encontra nenhum arquivo estático com esse nome e devolve a página HTML de fallback (status 404).
- O sistema de autenticação rejeita a resposta por não ser JSON e impede a tela branca.

---

## Como Colocar o Backend no Ar e Conectar ao Netlify

Para que o login e o painel administrativo funcionem em produção, o backend Node.js precisa estar rodando em um serviço que execute containers/Node.js (ex: **Render.com** ou **Railway.app**).

---

### OPÇÃO A: Backend no Render.com (Gratuito / Recomendado)

1. Crie ou acesse sua conta em [https://render.com](https://render.com).
2. Clique no botão **New +** e selecione **Web Service**.
3. Conecte seu repositório GitHub (`omniverseofc321-ux/omeflash01`).
4. Preencha as configurações do serviço:
   - **Name**: `vortex-api` (ou outro nome desejado)
   - **Region**: Qualquer região (ex: `Oregon (US West)` ou `Frankfurt`)
   - **Branch**: `main`
   - **Runtime**: `Node`
   - **Node Version**: Certifique-se de que o Node seja v22 (adicione a variável `NODE_VERSION=22` nas variáveis de ambiente, pois o SQLite utilizado requer Node 22+).
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
5. Em **Environment Variables** (Variáveis de Ambiente no Render), adicione:
   - `NODE_ENV`: `production`
   - `PORT`: `3000`
   - `NODE_VERSION`: `22`
   - `CORS_ORIGIN`: A URL do seu frontend no Netlify (ex: `https://seu-app.netlify.app` ou `*`)
   - `SESSION_SECRET`: Uma chave secreta qualquer para assinatura de tokens (ex: `vortex_super_secret_production_key_2026`)
   - `ADMIN_INITIAL_EMAIL`: `admin@vortexstream.com` (ou seu e-mail)
   - `ADMIN_INITIAL_PASSWORD`: `admin123456` (ou sua senha)
   - `ADMIN_INITIAL_NAME`: `Administrador Geral`
6. (Opcional, para persistência de dados no Render):
   - Adicione um **Disk** no Render montado no caminho `/data` ou `./data` para que o banco SQLite (`platform.db`) não seja resetado a cada novo deploy.
7. Clique em **Deploy Web Service**.
8. Aguarde o deploy terminar e copie a URL pública gerada pelo Render (ex: `https://vortex-api.onrender.com`).

---

### OPÇÃO B: Backend no Railway.app

1. Crie ou acesse sua conta em [https://railway.app](https://railway.app).
2. Clique em **New Project** > **Deploy from GitHub repo**.
3. Selecione o repositório do Vortex Stream.
4. Em **Settings**:
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
5. Em **Variables**:
   - `NODE_ENV`: `production`
   - `PORT`: `3000`
   - `CORS_ORIGIN`: `https://seu-app.netlify.app`
   - `SESSION_SECRET`: `sua_chave_secreta_segura`
   - `ADMIN_INITIAL_EMAIL`: `admin@vortexstream.com`
   - `ADMIN_INITIAL_PASSWORD`: `admin123456`
6. Em **Networking**, clique em **Generate Domain** para obter a URL pública (ex: `https://vortex-api.up.railway.app`).

---

### Etapa Final: Configurar o Netlify para Usar a URL do Backend

Com a URL do seu backend em mãos (seja do Render ou do Railway):

1. Acesse o painel do seu site no **Netlify** ([https://app.netlify.com](https://app.netlify.com)).
2. Navegue até **Site configuration** > **Environment variables**.
3. Adicione ou edite a variável:
   - **Key**: `VITE_API_URL`
   - **Value**: A URL do seu backend (ex: `https://vortex-api.onrender.com`).
     *(Não se preocupe com barras no final ou se colocar `/api`: o frontend normaliza automaticamente sem duplicar rotas).*
4. Acesse a aba **Deploys** no Netlify.
5. Clique em **Trigger deploy** > **Clear cache and deploy site** (necessário para que o Vite compile o novo valor de `VITE_API_URL` no bundle JS).
6. Pronto! Agora o frontend no Netlify se comunicará diretamente com o backend real em produção.

---

## Como Testar a Autenticação Real em Produção

1. Abra a URL do site no Netlify.
2. Clique em **Admin** no canto superior direito (ou acerte a rota `/admin`).
3. Preencha as credenciais padrão criadas na primeira inicialização do banco:
   - **E-mail**: `admin@vortexstream.com` (ou o configurado em `ADMIN_INITIAL_EMAIL`)
   - **Senha**: `admin123456` (ou a configurada em `ADMIN_INITIAL_PASSWORD`)
4. Clique em **Acessar Painel**.
5. O backend processará a validação criptográfica `scrypt`, gerará o token de sessão e o frontend abrirá o painel de gerenciamento completo de vídeos e planos.
